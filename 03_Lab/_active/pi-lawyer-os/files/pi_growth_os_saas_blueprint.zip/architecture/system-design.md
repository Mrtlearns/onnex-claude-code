
# System Architecture

Frontend
- React 18 + TypeScript + Vite
- Tailwind + shadcn/ui
- Framer Motion
- TanStack Query

Backend
- PostgreSQL
- PostgREST API
- pgvector embeddings
- Neo4j graph relationships

Automation
- n8n orchestration
- OpenClaw agent engine

Data flow:
Lead -> PostgREST -> n8n workflows -> Twilio -> Dashboard
