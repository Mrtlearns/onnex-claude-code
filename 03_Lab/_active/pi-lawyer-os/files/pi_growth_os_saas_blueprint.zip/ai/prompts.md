
# AI Prompt Library

Intake Summary Prompt
Summarize the intake transcript into:
- injury description
- liability
- next steps

Lead Scoring Prompt
Classify lead as:
Hot
Warm
Cold
