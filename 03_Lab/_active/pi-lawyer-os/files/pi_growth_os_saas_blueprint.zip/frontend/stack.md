
Frontend Stack

React 18
TypeScript
Vite
TailwindCSS
shadcn/ui
Framer Motion

Forms:
React Hook Form
Zod validation

Charts:
Recharts

State Management:
TanStack Query
