
# Dashboard Components

Partner Dashboard:
- Response time chart
- Missed calls recovered
- Signed cases
- Conversion funnel

Built using:
Recharts
