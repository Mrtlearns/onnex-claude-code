
# Neo4j Graph Model

Nodes:
Lead
Attorney
ReferralPartner
Case

Relationships:
(Lead)-[:REFERRED_BY]->(Partner)
(Lead)-[:BECAME]->(Case)
(Case)-[:HANDLED_BY]->(Attorney)
