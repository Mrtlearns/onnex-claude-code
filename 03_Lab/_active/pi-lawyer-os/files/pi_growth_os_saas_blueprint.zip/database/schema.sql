
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE firms (
  id UUID PRIMARY KEY,
  name TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE leads (
  id UUID PRIMARY KEY,
  firm_id UUID,
  first_name TEXT,
  last_name TEXT,
  phone TEXT,
  email TEXT,
  injury_type TEXT,
  source TEXT,
  status TEXT DEFAULT 'new',
  embedding vector(1536),
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE communications (
  id UUID PRIMARY KEY,
  lead_id UUID,
  channel TEXT,
  message TEXT,
  created_at TIMESTAMP DEFAULT now()
);
